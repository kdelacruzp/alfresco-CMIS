package com.alfresco.api.example.model;

import com.google.api.client.util.Key;

/**
 * @author jpotts
 */
public class NetworkEntry extends Entry {
    @Key
    public Network entry;
}
