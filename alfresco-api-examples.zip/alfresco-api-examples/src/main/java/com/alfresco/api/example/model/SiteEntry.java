package com.alfresco.api.example.model;

import com.google.api.client.util.Key;

/**
 * @author jpotts
 */
public class SiteEntry extends Entry {
    @Key
    public Site entry;
}
