package com.alfresco.api.example.model;

import com.google.api.client.util.Key;

/**
 * @author jpotts
 */
public class SiteList {
    @Key
    public List<SiteEntry> list;
}
