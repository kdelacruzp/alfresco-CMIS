package com.alfresco.api.example.model;

/**
 * @author jpotts
 */
public class Entry {

}
