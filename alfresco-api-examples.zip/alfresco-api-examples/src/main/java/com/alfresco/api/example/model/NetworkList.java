package com.alfresco.api.example.model;

import com.google.api.client.util.Key;

/**
 * @author jpotts
 */
public class NetworkList {
    @Key
    public List<NetworkEntry> list;
}
